#include<stdio.h>
 main()
{
	int a , b, sum;
	printf("Enter first number:");
	scanf("%d",&a);
	 
	 
	printf("Enter second number:");
	scanf("%d",&b);
	 
	sum=a+b;
	printf("The sum of %d and %d is %d",a,b,sum);
	 
	 return 0; //Don't forgot this..
}
