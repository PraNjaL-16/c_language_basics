#include<stdio.h>
int main()
{
  int count=1,n;
  /*here we have defined the count which increase as the ++ operator increases as comparable to the value of n*/
  scanf("%d",&n);
  while(count<=n)
   {
     printf("hello world \n");
     count++;
   }
  return 0;
}
