#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 

{
	float r;
	float v;
	float p;
	
	printf("Enter radius of Circle: ");
	scanf("%f",&r);
	
	hacim = (3.14)*r*r;
	printf("Volume of Circle: %.2f ",v);
	cevre = 2* (3.14)*r;
	printf("Perimeter: %.2f",p);

	return 0;
}
