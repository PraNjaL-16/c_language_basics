#include <stdio.h>

int main()
{
int a,b;
printf("Enter first number\n");
scanf("%d",&a);
  
printf("Enter second number\n");
scanf("%d",&a);
  
if(a>b)
printf("Largest number is %d",a);
else
printf("Largest number is %d",b);
return 0;
}
