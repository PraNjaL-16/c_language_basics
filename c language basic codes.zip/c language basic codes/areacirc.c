#include<stdio.h>
#define pi 3.14
int main()
{
        float r;
        printf("Enter the radius of the circle\n");
        scanf("%f",&r);
        printf("area of the circle: %6.2f\n",pi*r*r);
        return 0;
}
